//
//  Appointment.swift
//  Znajdz Termin
//
//  Created by Krzysztof Kuźmicki on 29/12/2025.
//

import Foundation
import SwiftData

@Model
final class Appointment {
    @Attribute(.unique) var id: UUID = UUID()
    var voivodeship: String
    var facilityName: String
    var serviceName: String
    var location: String
    var firstAvailableDate: String?
    var waitingTime: String?
    var phoneNumber: String?
    var address: String?
    var numberOfWaiting: Int?
    var distance: Double?
    var lastUpdated: Date
    
    init(voivodeship: String, facilityName: String, serviceName: String, location: String, firstAvailableDate: String? = nil, waitingTime: String? = nil, phoneNumber: String? = nil, address: String? = nil, numberOfWaiting: Int? = nil, distance: Double? = nil, lastUpdated: Date = Date()) {
        self.voivodeship = voivodeship
        self.facilityName = facilityName
        self.serviceName = serviceName
        self.location = location
        self.firstAvailableDate = firstAvailableDate
        self.waitingTime = waitingTime
        self.phoneNumber = phoneNumber
        self.address = address
        self.numberOfWaiting = numberOfWaiting
        self.distance = distance
        self.lastUpdated = lastUpdated
    }
}

enum Voivodeship: String, CaseIterable, Identifiable {
    case dolnoslaskie = "dolnośląskie"
    case kujawskoPomorskie = "kujawsko-pomorskie"
    case lubelskie = "lubelskie"
    case lubuskie = "lubuskie"
    case lodzkie = "łódzkie"
    case malopolskie = "małopolskie"
    case mazowieckie = "mazowieckie"
    case opolskie = "opolskie"
    case podkarpackie = "podkarpackie"
    case podlaskie = "podlaskie"
    case pomorskie = "pomorskie"
    case slaskie = "śląskie"
    case swietokrzyskie = "świętokrzyskie"
    case warminskoMazurskie = "warmińsko-mazurskie"
    case wielkopolskie = "wielkopolskie"
    case zachodniopomorskie = "zachodniopomorskie"
    
    var id: String { rawValue }
    
    var displayName: String {
        switch self {
        case .dolnoslaskie: return "Dolnośląskie"
        case .kujawskoPomorskie: return "Kujawsko-Pomorskie"
        case .lubelskie: return "Lubelskie"
        case .lubuskie: return "Lubuskie"
        case .lodzkie: return "Łódzkie"
        case .malopolskie: return "Małopolskie"
        case .mazowieckie: return "Mazowieckie"
        case .opolskie: return "Opolskie"
        case .podkarpackie: return "Podkarpackie"
        case .podlaskie: return "Podlaskie"
        case .pomorskie: return "Pomorskie"
        case .slaskie: return "Śląskie"
        case .swietokrzyskie: return "Świętokrzyskie"
        case .warminskoMazurskie: return "Warmińsko-Mazurskie"
        case .wielkopolskie: return "Wielkopolskie"
        case .zachodniopomorskie: return "Zachodniopomorskie"
        }
    }
    
    var fileID: String {
        switch self {
        case .dolnoslaskie: return "45fc5762-77c1-ce0c-e063-b4200a0a3c21"
        case .kujawskoPomorskie: return "45fc5762-77c2-ce0c-e063-b4200a0a3c21"
        case .lubelskie: return "45fc5762-77c3-ce0c-e063-b4200a0a3c21"
        case .lubuskie: return "45fc5762-77c4-ce0c-e063-b4200a0a3c21"
        case .lodzkie: return "45fc5762-77c5-ce0c-e063-b4200a0a3c21"
        case .malopolskie: return "45fc5762-77c6-ce0c-e063-b4200a0a3c21"
        case .mazowieckie: return "45fc5762-77c7-ce0c-e063-b4200a0a3c21"
        case .opolskie: return "45fc5762-77c8-ce0c-e063-b4200a0a3c21"
        case .podkarpackie: return "45fc5762-77c9-ce0c-e063-b4200a0a3c21"
        case .podlaskie: return "45fc5762-77ca-ce0c-e063-b4200a0a3c21"
        case .pomorskie: return "45fc5762-77cb-ce0c-e063-b4200a0a3c21"
        case .slaskie: return "45fc5762-77cc-ce0c-e063-b4200a0a3c21"
        case .swietokrzyskie: return "45fc5762-77cd-ce0c-e063-b4200a0a3c21"
        case .warminskoMazurskie: return "45fc5762-77ce-ce0c-e063-b4200a0a3c21"
        case .wielkopolskie: return "45fc5762-77cf-ce0c-e063-b4200a0a3c21"
        case .zachodniopomorskie: return "45fc5762-77d0-ce0c-e063-b4200a0a3c21"
        }
    }
    
    var centerCoordinates: (lat: Double, lon: Double) {
        switch self {
        case .dolnoslaskie: return (51.1, 17.0)
        case .kujawskoPomorskie: return (53.0, 18.5)
        case .lubelskie: return (51.2, 22.6)
        case .lubuskie: return (52.0, 15.5)
        case .lodzkie: return (51.8, 19.5)
        case .malopolskie: return (50.1, 19.9)
        case .mazowieckie: return (52.2, 21.0)
        case .opolskie: return (50.7, 17.9)
        case .podkarpackie: return (50.0, 22.0)
        case .podlaskie: return (53.1, 23.2)
        case .pomorskie: return (54.4, 18.6)
        case .slaskie: return (50.3, 19.0)
        case .swietokrzyskie: return (50.9, 20.6)
        case .warminskoMazurskie: return (53.8, 20.5)
        case .wielkopolskie: return (52.4, 16.9)
        case .zachodniopomorskie: return (53.4, 14.6)
        }
    }
    
    static func from(latitude: Double, longitude: Double) -> Voivodeship {
        var closest: Voivodeship = .mazowieckie
        var minDistance: Double = Double.infinity
        
        for voivodeship in Voivodeship.allCases {
            let coords = voivodeship.centerCoordinates
            let distance = sqrt(pow(latitude - coords.lat, 2) + pow(longitude - coords.lon, 2))
            if distance < minDistance {
                minDistance = distance
                closest = voivodeship
            }
        }
        
        return closest
    }
}
