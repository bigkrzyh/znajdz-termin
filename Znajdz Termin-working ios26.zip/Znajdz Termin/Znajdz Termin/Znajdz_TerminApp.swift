//
//  Znajdz_TerminApp.swift
//  Znajdz Termin
//
//  Created by Krzysztof Kuźmicki on 29/12/2025.
//

import SwiftUI
import SwiftData

@main
struct Znajdz_TerminApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: Appointment.self)
    }
}
