//
//  AppointmentRowView.swift
//  Znajdz Termin
//
//  Created by Krzysztof Kuźmicki on 29/12/2025.
//

import SwiftUI

struct AppointmentRowView: View {
    let appointment: Appointment
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            // Facility name
            Text(appointment.facilityName)
                .font(.headline)
                .foregroundColor(.primary)
            
            // Service name
            Label(appointment.serviceName, systemImage: "stethoscope")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            // Location
            Label(appointment.location, systemImage: "mappin.circle")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            // First available date
            if let date = appointment.firstAvailableDate, !date.isEmpty {
                Label(date, systemImage: "calendar")
                    .font(.subheadline)
                    .foregroundColor(.blue)
            }
            
            // Waiting time
            if let waiting = appointment.waitingTime, !waiting.isEmpty {
                Label(waiting, systemImage: "clock")
                    .font(.subheadline)
                    .foregroundColor(.orange)
            }
            
            // Number waiting
            if let number = appointment.numberOfWaiting, number > 0 {
                Label("Liczba oczekujących: \(number)", systemImage: "person.2")
                    .font(.subheadline)
                    .foregroundColor(.red)
            }
            
            // Address
            if let address = appointment.address, !address.isEmpty {
                Label(address, systemImage: "house")
                    .font(.caption)
                    .foregroundColor(.blue)
            }
            
            // Phone (tappable)
            if let phone = appointment.phoneNumber, !phone.isEmpty {
                let cleanPhone = phone.replacingOccurrences(of: " ", with: "")
                    .replacingOccurrences(of: "-", with: "")
                    .replacingOccurrences(of: "(", with: "")
                    .replacingOccurrences(of: ")", with: "")
                
                if let phoneURL = URL(string: "tel:\(cleanPhone)") {
                    Link(destination: phoneURL) {
                        Label(phone, systemImage: "phone.fill")
                            .font(.subheadline)
                            .foregroundColor(.green)
                    }
                } else {
                    Label(phone, systemImage: "phone")
                        .font(.subheadline)
                        .foregroundColor(.green)
                }
            }
            
            // Distance
            if let distance = appointment.distance {
                Label(String(format: "Odległość: %.1f km", distance), systemImage: "location")
                    .font(.subheadline)
                    .foregroundColor(.purple)
            }
        }
    }
}

#Preview {
    AppointmentRowView(appointment: Appointment(
        voivodeship: "mazowieckie",
        facilityName: "Szpital Testowy",
        serviceName: "Kardiologia",
        location: "Warszawa",
        firstAvailableDate: "2025-01-15",
        waitingTime: "30 dni",
        phoneNumber: "+48 123 456 789",
        address: "ul. Testowa 1",
        numberOfWaiting: 10,
        distance: 5.5
    ))
    .padding()
}
