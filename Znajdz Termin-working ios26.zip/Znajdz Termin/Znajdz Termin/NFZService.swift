//
//  NFZService.swift
//  Znajdz Termin
//
//  Created by Krzysztof Kuźmicki on 29/12/2025.
//

import Foundation
import SwiftData
import Combine

@MainActor
class NFZService: ObservableObject {
    @Published var appointments: [Appointment] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var selectedVoivodeship: Voivodeship?
    @Published var selectedServiceName: String?
    @Published var locationFilter: String = ""
    @Published var serviceNames: [String] = []
    @Published var lastUpdateDate: Date?
    @Published var isSearching = false
    @Published var hasSearched = false
    
    private let modelContext: ModelContext
    private let locationManager: LocationManager
    
    init(modelContext: ModelContext, locationManager: LocationManager) {
        self.modelContext = modelContext
        self.locationManager = locationManager
        
        // Load last used voivodeship
        if let savedVoivodeship = UserDefaults.standard.string(forKey: "lastUsedVoivodeship"),
           let voivodeship = Voivodeship.allCases.first(where: { $0.rawValue == savedVoivodeship }) {
            selectedVoivodeship = voivodeship
        }
    }
    
    func downloadAndParseVoivodeship(_ voivodeship: Voivodeship, forceRefresh: Bool = false) async throws {
        print("NFZService: Starting download for \(voivodeship.rawValue)")
        isLoading = true
        errorMessage = nil
        
        defer {
            isLoading = false
        }
        
        let voivodeshipString = voivodeship.rawValue
        
        // Check cache first
        if !forceRefresh && FileCacheManager.shared.fileExists(for: voivodeshipString) {
            do {
                print("NFZService: Loading from cache")
                let cachedData = try FileCacheManager.shared.loadFile(for: voivodeshipString)
                let (sharedStrings, sheet1) = try ZIPExtractor.extractExcelFiles(from: cachedData)
                let parsedAppointments = try ExcelParser.parse(sharedStringsData: sharedStrings, sheet1Data: sheet1, voivodeship: voivodeshipString)
                
                print("NFZService: Parsed \(parsedAppointments.count) appointments from cache")
                
                // Store in database
                try storeAppointments(parsedAppointments, for: voivodeshipString)
                
                lastUpdateDate = FileCacheManager.shared.getLastUpdateDate(for: voivodeshipString)
                await updateServiceNames(for: voivodeship)
                return
            } catch {
                print("NFZService: Cache invalid, downloading fresh: \(error)")
            }
        }
        
        // Download file
        print("NFZService: Downloading from server for \(voivodeship.rawValue)")
        let downloadURL = try await DownloadPageScraper.getDownloadURL(for: voivodeship)
        print("NFZService: Download URL: \(downloadURL)")
        
        guard let url = URL(string: downloadURL) else {
            throw NSError(domain: "NFZService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Nieprawidłowy URL"])
        }
        
        // Create request with browser-like headers
        var request = URLRequest(url: url)
        request.setValue("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", forHTTPHeaderField: "User-Agent")
        request.setValue("*/*", forHTTPHeaderField: "Accept")
        request.setValue("https://terminyleczenia.nfz.gov.pl", forHTTPHeaderField: "Referer")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        // Log response details
        if let httpResponse = response as? HTTPURLResponse {
            print("NFZService: Status: \(httpResponse.statusCode), Size: \(data.count) bytes")
            if let contentType = httpResponse.value(forHTTPHeaderField: "Content-Type") {
                print("NFZService: Content-Type: \(contentType)")
            }
        }
        
        // Validate and process the downloaded data
        try await processDownloadedData(data, response: response, voivodeship: voivodeship, voivodeshipString: voivodeshipString)
    }
    
    private func processDownloadedData(_ data: Data, response: URLResponse, voivodeship: Voivodeship, voivodeshipString: String) async throws {
        print("NFZService: Processing downloaded data (\(data.count) bytes)")
        
        // Check if data is valid
        guard data.count > 0 else {
            throw NSError(domain: "NFZService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Pobrano pusty plik"])
        }
        
        // Check file signature first - Excel files are ZIP archives starting with PK
        let zipSignature: [UInt8] = [0x50, 0x4B, 0x03, 0x04] // "PK.."
        if data.count >= 4 {
            let fileSignature = Array(data.prefix(4))
            if fileSignature == zipSignature {
                print("NFZService: File signature OK (ZIP/Excel format)")
            } else {
                print("NFZService: File signature mismatch!")
                print("NFZService: Expected: \(zipSignature.map { String(format: "%02x", $0) }.joined(separator: " "))")
                print("NFZService: Got: \(fileSignature.map { String(format: "%02x", $0) }.joined(separator: " "))")
                
                // Check if it's HTML
                if let text = String(data: data.prefix(2000), encoding: .utf8) {
                    let lowerText = text.lowercased()
                    if lowerText.contains("<!doctype") || lowerText.contains("<html") || lowerText.contains("<body") {
                        print("NFZService: File appears to be HTML")
                        print("NFZService: HTML content (first 2000 chars):")
                        print(String(repeating: "=", count: 80))
                        print(String(text.prefix(2000)))
                        print(String(repeating: "=", count: 80))
                        
                        // Try to extract error message from HTML
                        var errorMessage = "Otrzymano stronę HTML zamiast pliku Excel"
                        if let titleRange = text.range(of: "<title>", options: .caseInsensitive) {
                            let afterTitle = text[titleRange.upperBound...]
                            if let titleEndRange = afterTitle.range(of: "</title>", options: .caseInsensitive) {
                                let title = String(afterTitle[..<titleEndRange.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
                                if !title.isEmpty {
                                    errorMessage += ": \(title)"
                                }
                            }
                        }
                        
                        throw NSError(domain: "NFZService", code: 2, userInfo: [NSLocalizedDescriptionKey: errorMessage])
                    }
                }
                
                throw NSError(domain: "NFZService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Pobrany plik nie jest prawidłowym plikiem Excel"])
            }
        }
        
        // Check Content-Type header
        if let httpResponse = response as? HTTPURLResponse {
            if let contentType = httpResponse.value(forHTTPHeaderField: "Content-Type"),
               contentType.contains("text/html") {
                // Log HTML content
                if let text = String(data: data.prefix(2000), encoding: .utf8) {
                    print("NFZService: Content-Type says HTML (first 2000 chars):\n\(text)")
                }
                throw NSError(domain: "NFZService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Otrzymano stronę HTML zamiast pliku Excel"])
            }
        }
        
        // Parse file
        let (sharedStrings, sheet1) = try ZIPExtractor.extractExcelFiles(from: data)
        let parsedAppointments = try ExcelParser.parse(sharedStringsData: sharedStrings, sheet1Data: sheet1, voivodeship: voivodeshipString)
        
        print("NFZService: Parsed \(parsedAppointments.count) appointments")
        
        // Save to cache
        try FileCacheManager.shared.saveFile(data: data, for: voivodeshipString)
        lastUpdateDate = Date()
        
        // Store in database
        try storeAppointments(parsedAppointments, for: voivodeshipString)
        
        await updateServiceNames(for: voivodeship)
    }
    
    private func storeAppointments(_ appointments: [Appointment], for voivodeshipString: String) throws {
        // Delete old appointments for this voivodeship
        let descriptor = FetchDescriptor<Appointment>(
            predicate: #Predicate<Appointment> { appointment in
                appointment.voivodeship == voivodeshipString
            }
        )
        let existing = try modelContext.fetch(descriptor)
        print("NFZService: Deleting \(existing.count) old appointments")
        for appointment in existing {
            modelContext.delete(appointment)
        }
        
        // Save new appointments
        for appointment in appointments {
            modelContext.insert(appointment)
        }
        
        try modelContext.save()
        print("NFZService: Saved \(appointments.count) new appointments")
    }
    
    func search() async {
        guard let voivodeship = selectedVoivodeship else {
            errorMessage = "Wybierz województwo"
            return
        }
        
        isSearching = true
        errorMessage = nil
        hasSearched = true
        
        defer {
            isSearching = false
        }
        
        let voivodeshipString = voivodeship.rawValue
        
        // Ensure data is loaded
        do {
            let checkDescriptor = FetchDescriptor<Appointment>(
                predicate: #Predicate<Appointment> { appointment in
                    appointment.voivodeship == voivodeshipString
                }
            )
            let existing = try modelContext.fetch(checkDescriptor)
            
            print("NFZService: Found \(existing.count) existing appointments for \(voivodeshipString)")
            
            if existing.isEmpty {
                print("NFZService: No data, downloading...")
                try await downloadAndParseVoivodeship(voivodeship)
            }
        } catch {
            errorMessage = "Błąd pobierania danych: \(error.localizedDescription)"
            print("NFZService: Error: \(error)")
            return
        }
        
        // Fetch and filter results
        do {
            let fetchDescriptor = FetchDescriptor<Appointment>(
                predicate: #Predicate<Appointment> { appointment in
                    appointment.voivodeship == voivodeshipString
                },
                sortBy: [SortDescriptor(\.facilityName)]
            )
            var results = try modelContext.fetch(fetchDescriptor)
            
            print("NFZService: Fetched \(results.count) appointments")
            
            // Apply filters in memory
            if let serviceName = selectedServiceName, !serviceName.isEmpty {
                results = results.filter { $0.serviceName.localizedCaseInsensitiveContains(serviceName) }
            }
            
            if !locationFilter.isEmpty {
                results = results.filter { $0.location.localizedCaseInsensitiveContains(locationFilter) }
            }
            
            print("NFZService: After filtering: \(results.count) appointments")
            
            // Calculate distances in background
            await calculateDistances(for: &results)
            
            // Sort by distance if available
            results.sort { a, b in
                if let distA = a.distance, let distB = b.distance {
                    return distA < distB
                }
                return a.distance != nil
            }
            
            appointments = results
        } catch {
            errorMessage = "Błąd wyszukiwania: \(error.localizedDescription)"
            print("NFZService: Search error: \(error)")
        }
        
        // Save selected voivodeship
        UserDefaults.standard.set(voivodeship.rawValue, forKey: "lastUsedVoivodeship")
    }
    
    private func calculateDistances(for appointments: inout [Appointment]) async {
        for i in appointments.indices {
            let appointment = appointments[i]
            let address = appointment.address ?? appointment.location
            if let distance = await locationManager.calculateDistance(to: address, location: appointment.location) {
                appointments[i].distance = distance
            }
        }
    }
    
    func refreshData() async {
        guard let voivodeship = selectedVoivodeship else { return }
        
        // Clear cache and re-download
        DownloadPageScraper.clearCache()
        try? FileCacheManager.shared.deleteFile(for: voivodeship.rawValue)
        
        do {
            try await downloadAndParseVoivodeship(voivodeship, forceRefresh: true)
            await search()
        } catch {
            errorMessage = "Błąd odświeżania danych: \(error.localizedDescription)"
        }
    }
    
    func updateServiceNames(for voivodeship: Voivodeship) async {
        let voivodeshipString = voivodeship.rawValue
        do {
            let descriptor = FetchDescriptor<Appointment>(
                predicate: #Predicate<Appointment> { appointment in
                    appointment.voivodeship == voivodeshipString
                }
            )
            let appointments = try modelContext.fetch(descriptor)
            let uniqueServiceNames = Array(Set(appointments.map { $0.serviceName })).sorted()
            serviceNames = uniqueServiceNames
            print("NFZService: Loaded \(serviceNames.count) unique service names")
        } catch {
            print("NFZService: Error loading service names: \(error)")
        }
    }
    
    func getStatistics() -> Int? {
        guard selectedVoivodeship != nil, selectedServiceName != nil else {
            return nil
        }
        
        return appointments.compactMap { $0.numberOfWaiting }.reduce(0, +)
    }
}
