//
//  ContentView.swift
//  Znajdz Termin
//
//  Created by Krzysztof Kuźmicki on 29/12/2025.
//

import SwiftUI
import SwiftData
import CoreLocation
import CoreLocationUI

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @StateObject private var locationManager = LocationManager()
    @State private var service: NFZService?
    
    @State private var showVoivodeshipPicker = false
    @State private var showServiceNamePicker = false
    
    var body: some View {
        Group {
            if let service = service {
                MainContentView(
                    service: service,
                    locationManager: locationManager,
                    showVoivodeshipPicker: $showVoivodeshipPicker,
                    showServiceNamePicker: $showServiceNamePicker
                )
            } else {
                ProgressView("Ładowanie...")
            }
        }
        .onAppear {
            if service == nil {
                service = NFZService(modelContext: modelContext, locationManager: locationManager)
                locationManager.requestPermission()
                
                Task {
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                    if let location = locationManager.currentLocation {
                        let voivodeship = Voivodeship.from(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
                        service?.selectedVoivodeship = voivodeship
                    } else if service?.selectedVoivodeship == nil {
                        service?.selectedVoivodeship = .mazowieckie
                    }
                    
                    // Download mazowieckie data on first run
                    if let service = service {
                        if !FileCacheManager.shared.fileExists(for: "mazowieckie") {
                            // Test download first
                            await DownloadTester.testDownload(for: .mazowieckie)
                            try? await service.downloadAndParseVoivodeship(.mazowieckie)
                        }
                        await service.updateServiceNames(for: .mazowieckie)
                    }
                }
            }
        }
    }
}

struct MainContentView: View {
    @ObservedObject var service: NFZService
    @ObservedObject var locationManager: LocationManager
    @Binding var showVoivodeshipPicker: Bool
    @Binding var showServiceNamePicker: Bool
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                headerView
                filtersView
                searchButton
                resultsView
                bottomInfoBar
            }
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showVoivodeshipPicker) {
            VoivodeshipPickerView(selectedVoivodeship: $service.selectedVoivodeship)
        }
        .sheet(isPresented: $showServiceNamePicker) {
            ServiceNamePickerView(selectedServiceName: $service.selectedServiceName, serviceNames: service.serviceNames)
        }
    }
    
    private var headerView: some View {
        HStack {
            LogoView(size: 40)
            Text("Wyszukiwarka Terminów NFZ")
                .font(.title3)
                .bold()
            Spacer()
            Button(action: {
                Task {
                    await service.refreshData()
                }
            }) {
                Image(systemName: "arrow.clockwise")
                    .foregroundColor(.blue)
            }
        }
        .padding()
        .background(Color(UIColor.systemBackground))
    }
    
    private var filtersView: some View {
        VStack(spacing: 12) {
            Button(action: { showVoivodeshipPicker = true }) {
                HStack {
                    Text(service.selectedVoivodeship?.displayName ?? "Województwo")
                        .foregroundColor(service.selectedVoivodeship != nil ? .primary : .gray)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color(UIColor.systemGray6))
                .cornerRadius(8)
            }
            
            Button(action: { showServiceNamePicker = true }) {
                HStack {
                    Text(service.selectedServiceName ?? "Nazwa świadczenia (opcjonalnie)")
                        .foregroundColor(service.selectedServiceName != nil ? .primary : .gray)
                        .lineLimit(1)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color(UIColor.systemGray6))
                .cornerRadius(8)
            }
            
            TextField("Miejscowość (opcjonalnie)", text: $service.locationFilter)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
        .padding(.horizontal)
    }
    
    private var searchButton: some View {
        Button(action: {
            Task {
                await service.search()
            }
        }) {
            HStack {
                if service.isSearching {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                } else {
                    Text("Szukaj")
                        .fontWeight(.semibold)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(service.selectedVoivodeship != nil ? Color.blue : Color.gray)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
        .disabled(service.selectedVoivodeship == nil || service.isSearching)
        .padding(.horizontal)
        .padding(.top, 12)
    }
    
    private var resultsView: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                if service.isSearching && service.appointments.isEmpty {
                    VStack(spacing: 16) {
                        ProgressView()
                        Text("Wyszukiwanie...")
                    }
                    .padding(.top, 50)
                } else if let error = service.errorMessage {
                    VStack(spacing: 16) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.largeTitle)
                            .foregroundColor(.orange)
                        Text(error)
                            .multilineTextAlignment(.center)
                        Text("Sprawdź połączenie internetowe i spróbuj ponownie.")
                            .font(.caption)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                    }
                    .padding()
                } else if !service.hasSearched {
                    VStack(spacing: 16) {
                        Image(systemName: "magnifyingglass")
                            .font(.largeTitle)
                            .foregroundColor(.gray)
                        Text("Wybierz województwo i kliknij Szukaj")
                            .foregroundColor(.gray)
                    }
                    .padding(.top, 50)
                } else if service.appointments.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "doc.text.magnifyingglass")
                            .font(.largeTitle)
                            .foregroundColor(.gray)
                        Text("Brak wyników")
                            .font(.headline)
                        Text("Spróbuj zmienić kryteria wyszukiwania")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.top, 50)
                } else {
                    Text("Znaleziono: \(service.appointments.count)")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal)
                        .padding(.top, 8)
                    
                    ForEach(service.appointments, id: \.id) { appointment in
                        AppointmentRowView(appointment: appointment)
                            .padding()
                            .background(Color(UIColor.systemBackground))
                        
                        Divider()
                    }
                }
            }
        }
        .refreshable {
            await service.refreshData()
        }
    }
    
    private var bottomInfoBar: some View {
        VStack(spacing: 4) {
            HStack {
                Text("Dzisiaj: \(formatDate(Date()))")
                    .font(.caption)
                Spacer()
                if let lastUpdate = service.lastUpdateDate {
                    Text("Dane: \(formatDate(lastUpdate))")
                        .font(.caption)
                }
            }
            
            if let statistics = service.getStatistics() {
                HStack {
                    Text("Liczba oczekujących: \(statistics)")
                        .font(.caption)
                        .foregroundColor(.red)
                    Spacer()
                }
            }
        }
        .padding()
        .background(Color(UIColor.systemGray6))
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pl_PL")
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

#Preview {
    ContentView()
        .modelContainer(for: Appointment.self, inMemory: true)
}
