//
//  VoivodeshipPickerView.swift
//  Znajdz Termin
//
//  Created by Krzysztof Kuźmicki on 29/12/2025.
//

import SwiftUI

struct VoivodeshipPickerView: View {
    @Binding var selectedVoivodeship: Voivodeship?
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            List {
                ForEach(Voivodeship.allCases) { voivodeship in
                    Button(action: {
                        selectedVoivodeship = voivodeship
                        dismiss()
                    }) {
                        HStack {
                            Text(voivodeship.displayName)
                                .foregroundColor(.primary)
                            Spacer()
                            if selectedVoivodeship == voivodeship {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Województwo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Anuluj") {
                        dismiss()
                    }
                }
            }
        }
    }
}

#Preview {
    VoivodeshipPickerView(selectedVoivodeship: .constant(.mazowieckie))
}
